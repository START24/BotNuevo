# `👑 Itsuki Nakano - IA V2` ✨
[![Typing SVG](https://readme-typing-svg.demolab.com?font=Oswald+Code&pause=1000&color=FF69B4&width=435&lines=Bienvenido+al+Repositorio;Itsuki+Nakano+IA+V2;Versión+6.4.1+Oficial;Creado+por+LeoXzzsy;)](https://git.io/typing-svg)

<!-- Banner -->
<h1 align="center">
  <img src="https://qu.ax/yhEAM.jpg" width="700" alt="Itsuki-Nakano IA Banner Ofc"/>
</h1>

[![Version](https://img.shields.io/badge/Version-6.4.1-pink.svg)]()
[![Baileys](https://img.shields.io/badge/Baileys-Multi--Device-blue.svg)]()
[![Plugins](https://img.shields.io/badge/Plugins-1000+-success.svg)]()
[![Speed](https://img.shields.io/badge/Speed-⚡Ultra--Fast-yellow.svg)]()
[![Node.js](https://img.shields.io/badge/Node.js-18+-green.svg)]()
[![License](https://img.shields.io/badge/License-MIT-orange.svg)]()

# 🎀 `Itsuki Nakano IA - V2` 🌸

**Bot Multi-Prefijo con Sistema de Comandos Avanzado**  
*La evolución del bot temático más completo de WhatsApp - ¡Ahora con más potencia y personalización!*

 <img src="https://github.com/BrayanOFC-Li/Lines-Neon-MB/raw/main/assets_MB/line-neon.gif" width="400"/>
</p>

### **`𝗧𝗼𝗰𝗮 𝗟𝗮 𝗜𝗺𝗮𝗴𝗲𝗻 𝗣𝗮𝗿𝗮 𝗗𝗲𝘀𝗰𝗮𝗿𝗴𝗮𝗿 𝗧𝗲𝗿𝗺𝘂𝘅 𝗔𝗰𝘁𝘂𝗮𝗹𝗶𝘇𝗮𝗱𝗼☕️`**
<a
href="https://www.mediafire.com/file/wkinzgpb0tdx5qh/com.termux_1022.apk/file"><img src="https://qu.ax/uYEOh.jpg" height="125px"></a> 

### **`🌸 Instalación por termux`**

> *Comandos para instalar de forma manual*
```bash
termux-setup-storage
```
```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```
```bash
git clone https://github.com/leoxito/Itsuki-NakanoV2 && cd Itsuki-NakanoV2
```
```bash
npm install
```
```bash
npm start
```

### **`ʟᴇᴏ ᴘʀᴏᴘɪᴇᴛᴀʀɪᴏ ᴅᴇʟ ᴘʀᴏʏᴇᴄᴛᴏ`**
<a
href="https://github.com/leoxito"><img src="https://github.com/leoxito.png" width="130" height="130" alt="xzzys26"/></a>


## `Colaboradores y Agradecimiento` ❤️

<a href="https://github.com/xzzys26/Itsuki-NakanoV2/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=xzzys26/Itsuki-IA&cache=bust" alt="Contribuidores">
</a>